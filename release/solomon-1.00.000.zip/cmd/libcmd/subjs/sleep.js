WScript.Sleep(WScript.Arguments(0));
